# rm -rf mac-classic-pram.dat
pce-macplus -v -c mac-classic.cfg -l pce.log -I rtc.romdisk=0 -r
