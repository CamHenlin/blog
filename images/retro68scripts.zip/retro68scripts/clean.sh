rm -rf Dialog/build
rm -rf Dialog/Debug
rm -rf HelloWorld/build
rm -rf HelloWorld/Debug
rm -rf MenuSample/build
rm -rf MenuSample/Debug
